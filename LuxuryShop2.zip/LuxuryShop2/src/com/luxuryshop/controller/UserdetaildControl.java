package com.luxuryshop.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lunxuryshop.pojo.Userdetaild;
import com.luxuryshop.Iservice.userdetaildService;
import com.luxuryshop.Iservice.Impl.userdetaildServiceImpl;



@Controller
@SessionAttributes("userdetaild")  //��model�е�userdetaild(Ҳ��key)��������,��֤��session�д���userdetaild�������
public class UserdetaildControl {
	@Autowired
	userdetaildService u;
	
/*	//�Ƿ�ҳ��ѯȫ��
	@RequestMapping("select")
	public  String findall(Model m){	
		List<Userdetaild> list = u.FoundAll();
		m.addAttribute("list", list);
//		return "userdetails";
	}*/
	
	
	
	//��ҳ��ѯȫ��
	@RequestMapping("select")
	public  String findall(Model m){	
		List<Userdetaild> lists = u.FoundAll();
		m.addAttribute("lists", lists);
		return "redirect:/pages/main.do";
	}	
	//��ҳ��ѯ
	@RequestMapping("main")
	public String  main(@RequestParam(value="currentPage",defaultValue="1",required=false)int currentPage,Model model){
		model.addAttribute("pagemsg", u.findByPage(currentPage));//���Է�ҳ����
		return "pages/main";
	}

	
	//����ID��ѯ
	@RequestMapping("selectById")
	public String findById(Model m,HttpSession ht){
		Integer id = (Integer) ht.getAttribute("id");
//		System.out.println(id);
		Userdetaild Userdetaild = u.FoundById(id);
		m.addAttribute("Userdetaild",Userdetaild);
//		System.out.println(Userdetaild.getAddress());
		return "pages/UserdetaildById";		
	}
	
	//����
	@RequestMapping("updateById")
	public String updateByID(Userdetaild ud,Model m,HttpServletRequest request){
		m.addAttribute("tranValue", ud);
		String[] sexValues = request.getParameterValues("sex");
		for(int i=0;i<sexValues.length;i++) {
				 if(sexValues[i].equals("1")) {
					ud.setSex(1);
					}else {
				     ud.setSex(2);
					}
		}
		System.out.println(ud);
		u.UpdateInformation(ud);
		return "redirect:/pages/select.do";	
	}
	//��ֵ���޸�ҳ��
	@RequestMapping("toupdate")
	public String transmitValue(int uid,Model m){
		Userdetaild tranValue = u.FoundById(uid);
		m.addAttribute("tranValue", tranValue);
		return "pages/UdateUserDetaildById";
		
	}
	
	//����
	@RequestMapping("insertUserdetaild")
	public String insertUD(Userdetaild ud){
		u.InsertUserDetaild(ud);
		return "redirect:/pages/select.do";
	}
	
	//ɾ��
	@RequestMapping("deleteById")
	public String deleteByID(int uid){
        u.DeleteUserDetaild(uid);
		return "redirect:/pages/select.do";
	}
}
