package com.luxuryshop.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.InputExample;
import com.luxuryshop.Iservice.inputService;


@Controller
@RequestMapping("input")
public class inputControl {
@Autowired
private inputService s;

@RequestMapping("selectAll")
public String selectAll(Model m)
{	
	InputExample example = null;
	List<Input> in = new ArrayList<Input>();
	in = s.selectByExample(example);
	m.addAttribute("inputAll", in);
	return "admin/input";
	
}


@RequestMapping("selectById")
public String selectById(Model m)
{
	Input in = s.selectByPrimaryKey(1);
	m.addAttribute("Input", in);
	return "admin/inputSelect";
	
}

@RequestMapping("deletById")
public String selectById(Integer inid)
{
	s.deleteByPrimaryKey(inid);
	return "redirect:/input/selectAll.do";
	
}
@RequestMapping("deleteAll")
@ResponseBody
public void delecteAll(@RequestParam("list[]")List<String> list)
{	
	int inputId = 0;
	for (String string : list) {
		string = string.replaceAll(" ", ""); 
		if(!string.equals("on"))
		{
		inputId = Integer.parseInt(string);
		System.out.println(inputId);
		s.deleteByPrimaryKey(inputId);
		}
	
	}
	
}
@RequestMapping("addinput")
public String addinput(Input record)
{
	s.insert(record);
	return "redirect:/input/selectAll.do";
}

@RequestMapping("selectById2")
@ResponseBody
public Input addinput(Integer inid)
{
	Input selectByPrimaryKey = s.selectByPrimaryKey(inid);
	return selectByPrimaryKey;
}

@RequestMapping("updataInput")
public String updatainput(Input record)
{
	s.updateByPrimaryKey(record);
	return "redirect:/input/selectAll.do";
}

	
	  @RequestMapping("selectBygId") 
	  public String selectBygId(String gname,Model m) { 
		  System.out.println("1"); 
		  List<Input> selectBygIdlist = new ArrayList<Input>();
		  System.out.println("2"); selectBygIdlist =s.selectByGoodId(gname); 
		  System.out.println("3"); 
		  m.addAttribute("inputAll",selectBygIdlist); 
		  System.out.println("4"); 
		  return "admin/input"; 
		  }
	 
}
