package com.luxuryshop.controller;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.lunxuryshop.mapper.GoodsMapper;
import com.lunxuryshop.pojo.Shoppingcar;
import com.luxuryshop.Iservice.Igoods;
import com.luxuryshop.Iservice.Ishoppingcar;
import com.luxuryshop.Iservice.Impl.Shoppingcarimpl;

@Controller
public class Shoppingcarcontroller {
	@Autowired
	private Ishoppingcar carimpl;
	@Autowired
	private Igoods goodimpl;
	
	@RequestMapping(value = "toCheckout.do")
	public String toCheckout(Model mv,HttpSession hs) {
		Shoppingcar record=new Shoppingcar();
		/*
		 * if(hs.getAttribute("id")==null) { return "pages/Home"; } else {
		 */
			int userid=(int) hs.getAttribute("id");
			record.setUserid(userid);
			List<Shoppingcar> list = carimpl.selectUsercar(record);
			mv.addAttribute("list", list);
			return "pages/checkout";
//		}
			
		
	}
	
	 @RequestMapping(value = "addCarGoods.do")	  
	 @ResponseBody public int addCarGoods(int gid) 
	 { 
		 int uid=1;	 
		 System.out.println(gid);
	     return carimpl.addUserCar(uid,gid);
	 }
	
	  @RequestMapping(value = "deleteCarGoods.do")	 
	  @ResponseBody public String deleteGoods(int itemid) {
	  carimpl.deleteUserCar(itemid); 
	  return null;
	  }
	
	  @RequestMapping(value = "caculate.do")
	  @ResponseBody 
	  public float caculate(String[] allitemid) { 
		  float total=0.00f;
	      for (String string : allitemid) {
		  total=carimpl.caculate(Integer.parseInt(string))+total; 
		      }
		
		 return total; 
		 }
	  
	 @RequestMapping(value = "minusNum.do")
     @ResponseBody
     public String minusNum(int gid) { 
		 carimpl.minusUsercar(1, gid);
		 return "1";
		 }
	 
	 @RequestMapping(value = "addnum.do")	 
	 @ResponseBody public int addnum(int gid) {	
	  carimpl.addUserCar(1, gid);	 
	  return goodimpl.selectNum(gid);
	  
	 }
	 
	 @RequestMapping(value = "updatenum.do")
	  
	  @ResponseBody public int updateNum(int gid,int num) {	  
	  carimpl.updateNum(gid, num); 
	  return goodimpl.selectNum(gid); 
	  }
	 

}
