package com.luxuryshop.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lunxuryshop.pojo.Input;
import com.luxuryshop.Iservice.IInput;
import com.luxuryshop.Iservice.Impl.InputImpl;
@Controller("inputController")
public class InputController {
	@Autowired
	private IInput iInput;
	
	/*
    *从前台获取进货表的相关信息封装到input表对象，并将其插入到进货表
	 */
	@RequestMapping("addInput.do")
	public String addInput(Input input)
	{
		iInput.addInputs(input);
		return "success";
		
	}
	


}
