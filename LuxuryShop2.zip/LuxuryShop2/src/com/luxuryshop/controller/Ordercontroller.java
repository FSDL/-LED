package com.luxuryshop.controller;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lunxuryshop.pojo.Item;
import com.lunxuryshop.pojo.Order;
import com.lunxuryshop.pojo.Shoppingcar;
import com.luxuryshop.Iservice.Iitem;
import com.luxuryshop.Iservice.Iorder;
import com.luxuryshop.Iservice.Ishoppingcar;

@Controller
public class Ordercontroller {
	@Autowired
	private Ishoppingcar carimpl;
	@Autowired
	private Iitem itemimpl;
	@Autowired
	private Iorder orderimpl;
	
	@RequestMapping(value = "toOrder.do")
	private String toOrder(Model mv) {
		List<Order> list = orderimpl.selectUserOrders(1);
		mv.addAttribute("list", list);
		return "pages/Order";
	}
	@RequestMapping(value = "checkout.do")
	@ResponseBody
	public int checkout(String[] allitemid) {
		
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//�������ڸ�ʽ
		String nowtime=df.format(new Date());
		Timestamp date =Timestamp.valueOf(nowtime);
		int orderid=orderimpl.countOrderid();
		orderid++;
		for (String itemid : allitemid) {
			Shoppingcar record=carimpl.selectItem(Integer.parseInt(itemid));
			Order order=new Order();
			Item item=new Item();
			
			item.setItemid(record.getItemid());
			item.setGid(record.getGid());
			item.setNum(record.getNum());
			item.setPrice(record.getPrice());
			item.setUserid(1);
			itemimpl.insertItem(item);
			order.setOid(orderid);
			order.setUserid(record.getUserid());
			order.setItemid(record.getItemid());
			order.setDate(date);
			orderimpl.inserOrder(order);
			carimpl.deleteUserCar(Integer.parseInt(itemid));
		}
		
         return 1;
	}

}
