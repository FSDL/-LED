package com.luxuryshop.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.JOptionPane;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.lunxuryshop.pojo.User;
import com.lunxuryshop.pojo.Userdetaild;
import com.luxuryshop.Iservice.userService;
import com.luxuryshop.Iservice.userdetaildService;


@Controller
@SessionAttributes("user")  //��model�е�user(Ҳ��key)��������,��֤��session�д���user�������
public class UserControl {
	
	//ע��
	private String passwordF = null;
	private boolean checkPass = false;
	private User suser = null;
	@Autowired
	userService u; 
	@Autowired
	userdetaildService ud;
    @RequestMapping("register")
    @ResponseBody
    public String registerUserName(String name,HttpServletResponse response){
        boolean tOf = u.foundUser(name);
        String S = null;
        S = tOf+"";
        return S;
    }
   @RequestMapping("gunduzi")
   public String registerUserName2(){  
	   
       	return "pages/register";  
    }  
   @RequestMapping("checkpassword")
   @ResponseBody
   public String checkpassword(String password,HttpServletResponse response){
	   passwordF = password;
	   return passwordF;
   }
   //
   @RequestMapping("checkpassword2")
   @ResponseBody
   public String checkpassword2(String password2,HttpServletResponse response){
	   String c = null;
	   boolean equals = passwordF.equals(password2);
	   checkPass = equals;
	   System.out.println(checkPass);
	   c = equals+"";
	   return c;
   } 
   //�ύע��
   @RequestMapping("submitRegister")
   public String Register(User user){
	   User newuser = null;
	   System.out.println(user.getId());
	   if(checkPass==true){		   
		   int flag = u.register(user);
		   if(flag ==1){ 
			   JOptionPane.showMessageDialog(null, "注册成功");
		       return "pages/login";
		   }
		   else
			   return "pages/UserRegister"; 
	   }          
	   else
		   return "pages/error";	  //����ʧ��ҳ��
   }
   
   //��¼
   @RequestMapping("userlogin")
   public String userlogin(User user,HttpServletRequest req){	   
	   HttpSession s=req.getSession();		
	   int login = u.login(user);	   
	   if(login==1){
		   String name = user.getName();		   
		   suser = u.fundIDByName(name); 
		   System.out.println(suser.getId());//����ID
		   s.setAttribute("id", suser.getId());  //  ��session���ID
		   s.setAttribute("userSess", suser);
//		   System.out.println(suser.getId());		   
		   return "pages/index";
	   }else
		   return "pages/error";	   
   }  
   @RequestMapping("login")
   public String login(){
	   System.out.println("AAAA");
	   return "pages/login";
   }
     
   
   @RequestMapping("userById")
   public String founduserById(Model m,HttpSession ht){
	   Integer id = (Integer) ht.getAttribute("id");   //��session��ȡid
	   User user = u.selectById(id);	
	   m.addAttribute("user", user);
	   return "pages/UpdateUser";
   }
   
   //�޸�����
   @RequestMapping("updatePassword")
   public String updatePass(User user){
	   int update = u.UpdatePassword(user);
	   if(update==1){
		   return "pages/userInfo";
	   }
	   else
		   return "pages/error";
   } 
   
   //��ʾ�û�������ϸ��Ϣ
   @RequestMapping("updateUserInfo")
   public String updateUserInfo(Model m,HttpSession ht){
	   Integer id = (Integer) ht.getAttribute("id");
	   System.out.println("AAAA"+id);
	   Userdetaild userdetaild = ud.FoundById(id);
	   System.out.println(userdetaild.getName());
	   m.addAttribute("userdetaild", userdetaild);
	   return "pages/updateUserInfo";
   }
   //�ύ����
   @RequestMapping("submitUpdateInfo")
   public String submitUpdateDetaildInfo(Userdetaild userdetaild,HttpServletRequest request,HttpSession ht){
	   Integer id = (Integer) ht.getAttribute("id");
	   userdetaild.setUid(id);
	   String[] sexvalue = request.getParameterValues("sex");
	   for(int i=0;i<sexvalue.length;i++) {
		 if(sexvalue[i].equals("1")) {
			userdetaild.setSex(1);
			}else {
		     userdetaild.setSex(2);
			}
	   }
	   ud.UpdateInformation(userdetaild);
	   return "pages/userInfo";
   }
   
    
   //����Id��ѯ���˵�ȫ����Ϣ
   @RequestMapping("foundById")
   public String foundById(int id,Model m){
	   User userById = u.selectById(id);
	   m.addAttribute("userById", userById);
	   return "pages/userInfo";
   }
   
	//ע������
	@RequestMapping("outLogin")
	public String outLogin(HttpSession session){
		//ͨ��session.invalidata()������ע����ǰ��session
		session.invalidate();
		return "pages/login";
	}
   
}

