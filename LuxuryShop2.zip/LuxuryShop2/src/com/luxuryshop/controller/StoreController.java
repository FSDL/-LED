package com.luxuryshop.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lunxuryshop.pojo.Store;
import com.luxuryshop.Iservice.IStore;

import net.sf.json.JSONArray;
@Controller("storeController")
public class StoreController {
	@Autowired
	private  IStore istore;
	
	/*
	 * 鞋类库存
	 */
   
     @RequestMapping("shoes")
 	public String  addStoreShoes(Model m)
 	{
    	//istore.addStoreShoes();
 		List<Store> addStoreShoes = istore.selectStoreShoes(1);  //typeid值为1表示鞋类类型
 		//当库存小于或等于安全库存时，状态由安全变为不安全
 	    for (Store store : addStoreShoes) {
 	    	int num = store.getNum();
 	    	int minnum = store.getMinnum();
 	    	if (num <= minnum)
 	    	{
 	    		store.setState("不安全");
 	    		istore.updateStore(store);
 	    	}else {
 	    		store.setState("安全");
 	    		istore.updateStore(store);
 	    	}
			
		}
 		m.addAttribute("listStore", addStoreShoes);
 		if(!addStoreShoes.isEmpty())
 			System.out.println("StoreController:addStoreShoes()执行了。。。");
 		return "admin/storeShoes";		
 	}
     //模糊查询
     @RequestMapping("vagueSelectShoes")
  	public String  vagueSelectShoes(Model m,@RequestParam("keyword") String keyword)
  	{
  		List<Store> addStoreShoes = istore.vagueSelectShoes(keyword);  
  		System.out.println("模糊查询方法执行了。。。"+keyword);
  		m.addAttribute("listStore", addStoreShoes);
  		if(!addStoreShoes.isEmpty())
  			System.out.println("StoreController:addStoreShoes()执行了。。。");
  		return "admin/storeShoes";		
  	}
     
     //修改库存数据：安全库存
     @RequestMapping("updateStore")
     //public  String updateStore(@RequestParam(value = "inid",required = false) String id )
      public String updateStore(Store store)
     {
		  System.out.println("updateStore()方法执行了。。。");
    	 istore.updateStore(store);
          return "redirect:/shoes";
     }
     
     //按照inid查找Store
     @RequestMapping("selectStorebyId")
     public @ResponseBody Store selectStorebyId(@RequestParam("inputid") Integer inid)
     {
    	 Store selectStorebyId = istore.selectByInid(inid);
    	 System.out.println("selectStorebyId()执行了。。。"+selectStorebyId);
		 return selectStorebyId;
    	 
     }
     //按inid删除Store信息
     @RequestMapping("deleteByInid")
     public String deleteByInid(@RequestParam("inputid") Integer inid)
     {
    	 System.out.println("删除方法deleteByInid执行了！ ！ ！"+inid);
    	 istore.deleteByInid(inid);
    	 return "forward:admin/storeShoes";
     }
     
     //跳转后台首页
     @RequestMapping("tomanageIndex")
     public String tomanageIndex()
     {
    	 return "admin/manageIndex";
     }
     
     
     /*
      * 用于测试
      */
     @RequestMapping("Jsonshoes")
 	public @ResponseBody JSONArray addStoreShoesJson(Model m)
 	{
 		List<Store> addStoreShoes = istore.selectStoreShoes(1);  //typeid值为1表示鞋类类型
 		//将List<Store>转为JSON格式
 		JSONArray fromObject = JSONArray.fromObject(addStoreShoes);
 		System.out.println("将List<Store>转为JSON格式："+fromObject.toString());
 		m.addAttribute("listStore", addStoreShoes);
 		if(!addStoreShoes.isEmpty())
 			System.out.println("StoreController:addStoreShoesJson()执行了。。。");
 		//return "storeShoes";
 		return fromObject;
 		
 	}
     
     /*
      * 用于测试
      */
     @RequestMapping("toshoes")
     public String toshoes()
     {
    	 System.out.println("跳转到AjaxTest页面，再由AjaxTest.jsp获取List<Store>");
    	 return "admin/AjaxTest";
     }
     
}
