package com.luxuryshop.Iservice.Impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.GoodsMapper;
import com.lunxuryshop.pojo.Goods;
import com.luxuryshop.Iservice.Igoods;

@Service
public class Goodsimpl implements Igoods {

	@Autowired
	private GoodsMapper goodsdao;
	public List<Goods> selectAll() {
		return goodsdao.selectAll();
	}

	public int selectNum(int gid) {
	   return	goodsdao.selectNum(gid);
	}
	public Goods selectPriceAndName(int gid) {
		return goodsdao.selectPriceAndName( gid);
	}
	

}
