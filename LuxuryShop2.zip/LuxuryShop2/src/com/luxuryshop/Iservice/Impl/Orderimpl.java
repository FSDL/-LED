package com.luxuryshop.Iservice.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.OrderMapper;
import com.lunxuryshop.pojo.Order;
import com.luxuryshop.Iservice.Iorder;

@Service
public class Orderimpl implements Iorder {
	@Autowired
	private OrderMapper orderdao;

	public int inserOrder(Order record) {
		return orderdao.inserOrder(record);
	}

	public int countOrderid() {
		return orderdao.countOrderid();
	}

	public List<Order> selectUserOrders(int userid) {
		return orderdao.selectUserOrders(userid);
	}

}
