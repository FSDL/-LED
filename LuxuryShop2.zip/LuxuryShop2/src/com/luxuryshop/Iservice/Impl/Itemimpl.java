package com.luxuryshop.Iservice.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lunxuryshop.mapper.ItemMapper;
import com.lunxuryshop.pojo.Item;
import com.luxuryshop.Iservice.Iitem;
@Service
public class Itemimpl implements Iitem {
	@Autowired
	private ItemMapper itemdao;

	public int insertItem(Item record) {
		return itemdao.insert(record);
	}

}
