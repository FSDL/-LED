package com.luxuryshop.Iservice.Impl;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.StoreMapper;
import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.Store;
import com.lunxuryshop.pojo.StoreExample;
import com.luxuryshop.Iservice.IInput;
import com.luxuryshop.Iservice.IStore;
@Service("storeImpl")
public class StoreImpl implements IStore{

	@Autowired
    private StoreMapper storeManager;
	
	@Autowired
	private IInput iInput;
	
	/*
	 * 从进货表里查询信息，用于向库存表插入数据
	 */
	@Override
	public List<Store> addStoreShoes() {
		
		List<Store> liststore = new ArrayList<Store>();
		Store store = new Store();
		List<Input> selectInputs = iInput.selectInputs();
		
		for (Input input : selectInputs) {
			store.setInid(input.getInid());
			store.setGid(input.getGid());
			store.setNum(input.getInumber());
			store.setSize(input.getSize());
			store.setColor(input.getColor());
			store.setMinnum(input.getInumber()/2); //把安全库存初始化为库存的1/2
			store.setTypeid(input.getTypeid());
			storeManager.insert(store);
			liststore.add(store);
		}
		
		return liststore;
	}
	
	//模糊查询
	public List<Store> vagueSelectShoes(String keywd){
		return storeManager.vagueSelectShoes(keywd);
	}

	//按类型typeid查找store表的信息
	@Override
	public List<Store> selectStoreShoes(int typeid) {
			List<Store> selectByExample = storeManager.selectByTypeid(typeid);
		   return selectByExample;
	}
	
	//修改库存数据：安全库存和安全状态
	public  boolean updateStore(Store record) {
		storeManager.updateByPrimaryKeySelective( record);
		return false;
		
	}
	
	//按inid查找Store
	public Store selectByInid(int inid) {
		Store selectByPrimaryKey = storeManager.selectByInid(inid);
		return selectByPrimaryKey;
		
	}

	//按inid删除Store
	public void deleteByInid(int inid) {
		storeManager.deleteByPrimaryKey(inid);
	}


}
