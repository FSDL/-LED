package com.luxuryshop.Iservice.Impl;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.lunxuryshop.mapper.ShoppingcarMapper;
import com.lunxuryshop.pojo.Goods;
import com.lunxuryshop.pojo.Shoppingcar;
import com.luxuryshop.Iservice.Igoods;
import com.luxuryshop.Iservice.Ishoppingcar;


@Service
public class Shoppingcarimpl implements Ishoppingcar {
	@Autowired
	private ShoppingcarMapper cardao;
	@Autowired
	private Igoods goodsimpl;
	

	public List<Shoppingcar> selectUsercar(Shoppingcar record) {
		return cardao.selectUsercar(record);
	}

	public Shoppingcar selectNumOfCar(Shoppingcar record) {
		return cardao.selectNumOfCar(record);
	}

	public int addUserCar(int userid, int gid) {
		Shoppingcar car = new Shoppingcar();
		car.setGid(gid);
		car.setUserid(userid);
	    Shoppingcar iscar= cardao.selectNumOfCar(car);
	    if(iscar==null) {
	    	Goods good= goodsimpl.selectPriceAndName(gid);
	    	
	    	car.setGoodsname(good.getGoodsname());
	    	double price = good.getPrice();
	    	car.setPrice(price);
	    	car.setNum(1);
	    	return cardao.insertUserCar(car);
	    }else{
	    	int maxnum=goodsimpl.selectNum(gid);
	    	int savenum=iscar.getNum();
	    	if(savenum>=maxnum) {
	    		car.setNum(maxnum);
	    		cardao.updateUserCar(car);
	    		return maxnum;
	    	}
	    	else {
	    		car.setNum(savenum+1);
	    		return cardao.updateUserCar(car);
	    	}
	    }
	}

	public int deleteUserCar(int itemid) {
		return cardao.deleteUserCar(itemid);
	}

	public int minusUsercar(int userid, int gid) {
		Shoppingcar car = new Shoppingcar();
		car.setUserid(userid);
		car.setGid(gid);
		
		Shoppingcar savecar = cardao.selectNumOfCar(car);
		System.out.println(savecar.getNum());
	
		if(savecar.getNum()<=1) {
			car.setNum(1);
		}
		else {
			car.setNum(savecar.getNum()-1);
		}
	     return cardao.updateUserCar(car);
		
		
	}
		

	public float caculate(int itemid) {
		Shoppingcar record = new Shoppingcar();
		record.setUserid(1);
		record.setItemid(itemid);
		return cardao.caculate(record);		
	}
	public int updateNum(int gid, int num) {
		Shoppingcar record = new Shoppingcar();
		record.setUserid(1);
		record.setNum(num);
		record.setGid(gid);
		return cardao.updateUserCar(record);
	}

	public Shoppingcar selectItem(int itemid ) {
		return cardao.selectItem(itemid);
	}

}

