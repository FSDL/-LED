package com.luxuryshop.Iservice.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.InputMapper;
import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.InputExample;
import com.luxuryshop.Iservice.inputService;

@Service("inputServiceImpl")
public class inputServiceImpl implements inputService {
	@Autowired
	private InputMapper s;

	public Input selectByPrimaryKey(Integer inid) {
		// TODO Auto-generated method stub
		return s.selectByPrimaryKey(inid);
	}

	public List<Input> selectByExample(InputExample example) {
		return s.selectByExample(example);
	}

	public int deleteByPrimaryKey(Integer inid) {
		// TODO Auto-generated method stub
		return s.deleteByPrimaryKey(inid);
	}

	public boolean insert(Input record) {
		// TODO Auto-generated method stub
		s.insert(record);
		return true;
	}

	public int updateByPrimaryKey(Input record) {
		// TODO Auto-generated method stub
		return s.updateByPrimaryKey(record);
	}

	
	 public List<Input> selectByGoodId(String gname) { 
		 return s.selectByGoodId(gname);
		 }
	 

}
