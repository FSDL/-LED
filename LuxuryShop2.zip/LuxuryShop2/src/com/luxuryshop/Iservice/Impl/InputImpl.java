package com.luxuryshop.Iservice.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.InputMapper;
import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.InputExample;
import com.luxuryshop.Iservice.IInput;

@Service("inputImpl")
public class InputImpl implements IInput{
	@Autowired
	private InputMapper inputMapper;
	
   /*
    *从前台获取input表对象，并将其插入到进货表
    */
	@Override
	public int addInputs(Input input) {
		
		return inputMapper.insert(input);
	}
	/*
	 * 查找进货表的商品信息
	 */
	@Override
	public List<Input> selectInputs() {
		
		return inputMapper.selectByTypeid();
	}
	/*
	 * 模拟退掉进货的商品
	 * 从进货表里删除商品,并商品表里的商品下架和将库存表里的相应商品删除、
	 */
	@Override
	public int deleteInputs(Input input) {
		// TODO Auto-generated method stub
		return 0;
	}

}
