package com.luxuryshop.Iservice.Impl;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.lunxuryshop.mapper.UserdetaildMapper;
import com.lunxuryshop.pojo.PageBean;
import com.lunxuryshop.pojo.Userdetaild;
import com.luxuryshop.Iservice.userService;
import com.luxuryshop.Iservice.userdetaildService;
import com.luxuryshop.common.GetApplicationC;




@Service
public class userdetaildServiceImpl implements userdetaildService{
	
	List<Userdetaild> userdetailList = new ArrayList<Userdetaild>();
   @Autowired
   //����ȫ��   
	private UserdetaildMapper udm;
   
	public List<Userdetaild> FoundAll() {
		List<Userdetaild> userdetailList = udm.selectAll();
		return userdetailList;
	}

	//�����û�Id�����û���ϸ��Ϣ
	public Userdetaild FoundById(int id) {
		Userdetaild userdetail = udm.selectByPrimaryKey(id);
		return userdetail;
	}

	//�����û���ʵ���������û���ϸ��Ϣ
	public List<Userdetaild> FoundByName(String name) {
		List<Userdetaild> userdetail = udm.SelectByName(name);
		return userdetail;
	}

	public int InsertUserDetaild(Userdetaild ud) {
		int insertUD = 0;
	    insertUD = udm.insert(ud);
		return insertUD;
	}
    
	//userע��ʱͬʱ��Userdetaild������Ϣ
	public int DeleteUserDetaild(int id) {
		int deleteU=0;
		int deleteUd = udm.deleteByPrimaryKey(id);
		if(deleteUd==1){
			GetApplicationC t = new GetApplicationC();
			ApplicationContext ac = t.GetAC();
			userService bean = (userService) ac.getBean("userServiceImpl");
			deleteU = bean.deleteUser(id);
			return deleteU;   //���������û�ע���ɹ�������ʧ��
		}
		else{
			return 0;
		}
	}
    
	//�޸��û���ϸ��Ϣ
	public int UpdateInformation(Userdetaild ud) {
		int Userdetaild = 0;
		Userdetaild = udm.updateByPrimaryKey(ud);
		return Userdetaild;
	}

	//��ҳ��ѯȫ��
	public PageBean<Userdetaild> findByPage(int currentPage) {
		HashMap<String,Object> map = new HashMap<String,Object>();
		PageBean<Userdetaild> pageBean = new PageBean<Userdetaild>();
		
	    //��װ��ǰҳ��
        pageBean.setCurrPage(currentPage);
        
		//ÿҳ��ʾ������
		int pageSize=5;
		pageBean.setPageSize(pageSize);
		
		//��װ�ܼ�¼��
		int totalCount = udm.selectCount();
		pageBean.setTotalCount(totalCount);
		
		//��װ��ҳ��
		double tc = totalCount;
        Double num =Math.ceil(tc/pageSize);//����ȡ��
        pageBean.setTotalPage(num.intValue());
      
		map.put("start",(currentPage-1)*pageSize);
		map.put("size", pageBean.getPageSize());
		//��װÿҳ��ʾ������
		List<Userdetaild> lists = udm.findByPage(map);
		pageBean.setLists(lists);
		
		return pageBean;

	}


}
