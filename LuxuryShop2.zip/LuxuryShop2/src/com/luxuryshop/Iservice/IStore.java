package com.luxuryshop.Iservice;

import java.util.List;

import com.lunxuryshop.pojo.Store;

public interface IStore {
	
	  //从进货表里查询信息，用于向库存表插入数据
		public List<Store> addStoreShoes();
		
		//按类型typeid查找store表的信息
		public List<Store> selectStoreShoes(int typeid);
		
		//模糊查询
		public List<Store> vagueSelectShoes(String keywd);
        
		//修改库存数据：名称或安全库存
		public  boolean updateStore(Store record );
		
		//按inid查找Store
		public Store selectByInid(int inid);
		
		//按inid删除Store
		public void deleteByInid(int inid);	
		
		
		
}
