package com.luxuryshop.Iservice;
import java.util.List;
import com.lunxuryshop.pojo.Order;
public interface Iorder {
	
	int countOrderid();
	
	int inserOrder(Order record);
	
	List<Order> selectUserOrders(int userid);
}
