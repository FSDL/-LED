package com.luxuryshop.Iservice;
import com.lunxuryshop.pojo.Item;
public interface Iitem {
	 int insertItem(Item record);
}
