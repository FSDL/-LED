package com.luxuryshop.Iservice;

import java.util.List;

import com.lunxuryshop.pojo.Shoppingcar;

public interface Ishoppingcar {
	   
		 List<Shoppingcar> selectUsercar(Shoppingcar record);
		
		 Shoppingcar selectNumOfCar(Shoppingcar record); 
		
		int  addUserCar(int userid,int gid);
		
		int deleteUserCar(int itemid);
	
		int minusUsercar(int userid, int gid);
		
		float caculate( int itemid);
		
		int updateNum(int gid,int num);
		
		Shoppingcar selectItem(int itemid);    

}
