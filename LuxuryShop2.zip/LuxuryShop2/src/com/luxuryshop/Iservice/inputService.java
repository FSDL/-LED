package com.luxuryshop.Iservice;

import java.util.List;

import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.InputExample;


public interface inputService {
	Input selectByPrimaryKey(Integer inid);
	List<Input> selectByExample(InputExample example);
	int deleteByPrimaryKey(Integer inid);
	boolean insert(Input record);
	int updateByPrimaryKey(Input record);
	List<Input> selectByGoodId(String gname); 
}
