package com.luxuryshop.Iservice;


import java.util.List;

import com.lunxuryshop.pojo.Input;



public interface IInput {
	
	//插入商品信息到进货表
	public int addInputs(Input input);
	
	//查找进货表的商品信息
	public List<Input> selectInputs();
	
	/*模拟退掉进货的商品
	 * 从进货表里删除商品,并商品表里的商品下架和将库存表里的相应商品删除、
	 */
	public int deleteInputs(Input input);
   
}
