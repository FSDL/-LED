package com.luxuryshop.Iservice;
import java.util.List;
import com.lunxuryshop.pojo.Goods;
public interface Igoods {
     List<Goods> selectAll(); 
     
	 Goods selectPriceAndName(int gid);
	 
	 int selectNum(int gid);

}
