package com.luxuryshop.test;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;

@Component
public class JspTest {
	@RequestMapping("jspTest")
	public String jspTest()
	{
		System.out.println("ok ! ! !");
		return "finance";	
	}

}
