package com.luxuryshop.common;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.aspectj.lang.JoinPoint;
/*
 * LogAdive用于输出service和controller层中的类方法的执行信息的通知
 */
public class LogAdive {
	
	public void logbefore(JoinPoint joinpoint)
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String time = sdf.format(new Date());
		
		try {
			FileWriter writer = new FileWriter("d://luxuryShopLog.txt",true);
			writer.write("时间"+time);
			writer.write("执行"+joinpoint.getSignature()+"类的方法"+joinpoint.getSignature().getName()+"\n");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}

}
