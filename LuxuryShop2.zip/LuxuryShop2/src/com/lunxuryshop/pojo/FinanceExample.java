package com.lunxuryshop.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public class FinanceExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public FinanceExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        protected void addCriterionForJDBCDate(String condition, Date value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value.getTime()), property);
        }

        protected void addCriterionForJDBCDate(String condition, List<Date> values, String property) {
            if (values == null || values.size() == 0) {
                throw new RuntimeException("Value list for " + property + " cannot be null or empty");
            }
            List<java.sql.Date> dateList = new ArrayList<java.sql.Date>();
            Iterator<Date> iter = values.iterator();
            while (iter.hasNext()) {
                dateList.add(new java.sql.Date(iter.next().getTime()));
            }
            addCriterion(condition, dateList, property);
        }

        protected void addCriterionForJDBCDate(String condition, Date value1, Date value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            addCriterion(condition, new java.sql.Date(value1.getTime()), new java.sql.Date(value2.getTime()), property);
        }

        public Criteria andFidIsNull() {
            addCriterion("fId is null");
            return (Criteria) this;
        }

        public Criteria andFidIsNotNull() {
            addCriterion("fId is not null");
            return (Criteria) this;
        }

        public Criteria andFidEqualTo(Integer value) {
            addCriterion("fId =", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidNotEqualTo(Integer value) {
            addCriterion("fId <>", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidGreaterThan(Integer value) {
            addCriterion("fId >", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidGreaterThanOrEqualTo(Integer value) {
            addCriterion("fId >=", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidLessThan(Integer value) {
            addCriterion("fId <", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidLessThanOrEqualTo(Integer value) {
            addCriterion("fId <=", value, "fid");
            return (Criteria) this;
        }

        public Criteria andFidIn(List<Integer> values) {
            addCriterion("fId in", values, "fid");
            return (Criteria) this;
        }

        public Criteria andFidNotIn(List<Integer> values) {
            addCriterion("fId not in", values, "fid");
            return (Criteria) this;
        }

        public Criteria andFidBetween(Integer value1, Integer value2) {
            addCriterion("fId between", value1, value2, "fid");
            return (Criteria) this;
        }

        public Criteria andFidNotBetween(Integer value1, Integer value2) {
            addCriterion("fId not between", value1, value2, "fid");
            return (Criteria) this;
        }

        public Criteria andBatinIsNull() {
            addCriterion("batin is null");
            return (Criteria) this;
        }

        public Criteria andBatinIsNotNull() {
            addCriterion("batin is not null");
            return (Criteria) this;
        }

        public Criteria andBatinEqualTo(Float value) {
            addCriterion("batin =", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinNotEqualTo(Float value) {
            addCriterion("batin <>", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinGreaterThan(Float value) {
            addCriterion("batin >", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinGreaterThanOrEqualTo(Float value) {
            addCriterion("batin >=", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinLessThan(Float value) {
            addCriterion("batin <", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinLessThanOrEqualTo(Float value) {
            addCriterion("batin <=", value, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinIn(List<Float> values) {
            addCriterion("batin in", values, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinNotIn(List<Float> values) {
            addCriterion("batin not in", values, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinBetween(Float value1, Float value2) {
            addCriterion("batin between", value1, value2, "batin");
            return (Criteria) this;
        }

        public Criteria andBatinNotBetween(Float value1, Float value2) {
            addCriterion("batin not between", value1, value2, "batin");
            return (Criteria) this;
        }

        public Criteria andTypeinIsNull() {
            addCriterion("typein is null");
            return (Criteria) this;
        }

        public Criteria andTypeinIsNotNull() {
            addCriterion("typein is not null");
            return (Criteria) this;
        }

        public Criteria andTypeinEqualTo(Float value) {
            addCriterion("typein =", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinNotEqualTo(Float value) {
            addCriterion("typein <>", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinGreaterThan(Float value) {
            addCriterion("typein >", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinGreaterThanOrEqualTo(Float value) {
            addCriterion("typein >=", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinLessThan(Float value) {
            addCriterion("typein <", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinLessThanOrEqualTo(Float value) {
            addCriterion("typein <=", value, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinIn(List<Float> values) {
            addCriterion("typein in", values, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinNotIn(List<Float> values) {
            addCriterion("typein not in", values, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinBetween(Float value1, Float value2) {
            addCriterion("typein between", value1, value2, "typein");
            return (Criteria) this;
        }

        public Criteria andTypeinNotBetween(Float value1, Float value2) {
            addCriterion("typein not between", value1, value2, "typein");
            return (Criteria) this;
        }

        public Criteria andQuainIsNull() {
            addCriterion("quain is null");
            return (Criteria) this;
        }

        public Criteria andQuainIsNotNull() {
            addCriterion("quain is not null");
            return (Criteria) this;
        }

        public Criteria andQuainEqualTo(Float value) {
            addCriterion("quain =", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainNotEqualTo(Float value) {
            addCriterion("quain <>", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainGreaterThan(Float value) {
            addCriterion("quain >", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainGreaterThanOrEqualTo(Float value) {
            addCriterion("quain >=", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainLessThan(Float value) {
            addCriterion("quain <", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainLessThanOrEqualTo(Float value) {
            addCriterion("quain <=", value, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainIn(List<Float> values) {
            addCriterion("quain in", values, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainNotIn(List<Float> values) {
            addCriterion("quain not in", values, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainBetween(Float value1, Float value2) {
            addCriterion("quain between", value1, value2, "quain");
            return (Criteria) this;
        }

        public Criteria andQuainNotBetween(Float value1, Float value2) {
            addCriterion("quain not between", value1, value2, "quain");
            return (Criteria) this;
        }

        public Criteria andSuminIsNull() {
            addCriterion("sumin is null");
            return (Criteria) this;
        }

        public Criteria andSuminIsNotNull() {
            addCriterion("sumin is not null");
            return (Criteria) this;
        }

        public Criteria andSuminEqualTo(Float value) {
            addCriterion("sumin =", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminNotEqualTo(Float value) {
            addCriterion("sumin <>", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminGreaterThan(Float value) {
            addCriterion("sumin >", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminGreaterThanOrEqualTo(Float value) {
            addCriterion("sumin >=", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminLessThan(Float value) {
            addCriterion("sumin <", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminLessThanOrEqualTo(Float value) {
            addCriterion("sumin <=", value, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminIn(List<Float> values) {
            addCriterion("sumin in", values, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminNotIn(List<Float> values) {
            addCriterion("sumin not in", values, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminBetween(Float value1, Float value2) {
            addCriterion("sumin between", value1, value2, "sumin");
            return (Criteria) this;
        }

        public Criteria andSuminNotBetween(Float value1, Float value2) {
            addCriterion("sumin not between", value1, value2, "sumin");
            return (Criteria) this;
        }

        public Criteria andDayinIsNull() {
            addCriterion("dayin is null");
            return (Criteria) this;
        }

        public Criteria andDayinIsNotNull() {
            addCriterion("dayin is not null");
            return (Criteria) this;
        }

        public Criteria andDayinEqualTo(Float value) {
            addCriterion("dayin =", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinNotEqualTo(Float value) {
            addCriterion("dayin <>", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinGreaterThan(Float value) {
            addCriterion("dayin >", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinGreaterThanOrEqualTo(Float value) {
            addCriterion("dayin >=", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinLessThan(Float value) {
            addCriterion("dayin <", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinLessThanOrEqualTo(Float value) {
            addCriterion("dayin <=", value, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinIn(List<Float> values) {
            addCriterion("dayin in", values, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinNotIn(List<Float> values) {
            addCriterion("dayin not in", values, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinBetween(Float value1, Float value2) {
            addCriterion("dayin between", value1, value2, "dayin");
            return (Criteria) this;
        }

        public Criteria andDayinNotBetween(Float value1, Float value2) {
            addCriterion("dayin not between", value1, value2, "dayin");
            return (Criteria) this;
        }

        public Criteria andTimeIsNull() {
            addCriterion("time is null");
            return (Criteria) this;
        }

        public Criteria andTimeIsNotNull() {
            addCriterion("time is not null");
            return (Criteria) this;
        }

        public Criteria andTimeEqualTo(Date value) {
            addCriterionForJDBCDate("time =", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeNotEqualTo(Date value) {
            addCriterionForJDBCDate("time <>", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeGreaterThan(Date value) {
            addCriterionForJDBCDate("time >", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeGreaterThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("time >=", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeLessThan(Date value) {
            addCriterionForJDBCDate("time <", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeLessThanOrEqualTo(Date value) {
            addCriterionForJDBCDate("time <=", value, "time");
            return (Criteria) this;
        }

        public Criteria andTimeIn(List<Date> values) {
            addCriterionForJDBCDate("time in", values, "time");
            return (Criteria) this;
        }

        public Criteria andTimeNotIn(List<Date> values) {
            addCriterionForJDBCDate("time not in", values, "time");
            return (Criteria) this;
        }

        public Criteria andTimeBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("time between", value1, value2, "time");
            return (Criteria) this;
        }

        public Criteria andTimeNotBetween(Date value1, Date value2) {
            addCriterionForJDBCDate("time not between", value1, value2, "time");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}