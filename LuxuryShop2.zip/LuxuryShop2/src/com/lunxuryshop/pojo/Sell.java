package com.lunxuryshop.pojo;

public class Sell {
    private Integer sellid;

    private Integer gid;

    private Integer snumber;

    private Integer sarrtributeid;

    public Integer getSellid() {
        return sellid;
    }

    public void setSellid(Integer sellid) {
        this.sellid = sellid;
    }

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public Integer getSnumber() {
        return snumber;
    }

    public void setSnumber(Integer snumber) {
        this.snumber = snumber;
    }

    public Integer getSarrtributeid() {
        return sarrtributeid;
    }

    public void setSarrtributeid(Integer sarrtributeid) {
        this.sarrtributeid = sarrtributeid;
    }
}