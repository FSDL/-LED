package com.lunxuryshop.pojo;

public class Userdetaild {
    private Integer uid;

    private String name;

    private Integer age;

    private Integer sex;

    private String address;

    private String phonenumber;

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber == null ? null : phonenumber.trim();
    }

    
	@Override
	public String toString() {
		return "Userdetaild [uid=" + uid + ", name=" + name + ", age=" + age + ", sex=" + sex + ", address=" + address
				+ ", phonenumber=" + phonenumber + "]";
	}

	
	public Userdetaild() {
		super();
	}

	public Userdetaild(Integer uid, String name, Integer age, Integer sex, String address, String phonenumber) {
		super();
		this.uid = uid;
		this.name = name;
		this.age = age;
		this.sex = sex;
		this.address = address;
		this.phonenumber = phonenumber;
	}
    
    
}