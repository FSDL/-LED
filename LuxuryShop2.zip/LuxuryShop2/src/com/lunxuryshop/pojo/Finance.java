package com.lunxuryshop.pojo;

import java.util.Date;

public class Finance {
    private Integer fid;

    private Float batin;

    private Float typein;

    private Float quain;

    private Float sumin;

    private Float dayin;

    private Date time;

    public Integer getFid() {
        return fid;
    }

    public void setFid(Integer fid) {
        this.fid = fid;
    }

    public Float getBatin() {
        return batin;
    }

    public void setBatin(Float batin) {
        this.batin = batin;
    }

    public Float getTypein() {
        return typein;
    }

    public void setTypein(Float typein) {
        this.typein = typein;
    }

    public Float getQuain() {
        return quain;
    }

    public void setQuain(Float quain) {
        this.quain = quain;
    }

    public Float getSumin() {
        return sumin;
    }

    public void setSumin(Float sumin) {
        this.sumin = sumin;
    }

    public Float getDayin() {
        return dayin;
    }

    public void setDayin(Float dayin) {
        this.dayin = dayin;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}