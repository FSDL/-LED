package com.lunxuryshop.pojo;

public class Judge {
    private Integer jid;

    private Integer sorce;

    private Integer uid;

    private Integer gid;

    private byte[] jpicture;

    public Integer getJid() {
        return jid;
    }

    public void setJid(Integer jid) {
        this.jid = jid;
    }

    public Integer getSorce() {
        return sorce;
    }

    public void setSorce(Integer sorce) {
        this.sorce = sorce;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        this.uid = uid;
    }

    public Integer getGid() {
        return gid;
    }

    public void setGid(Integer gid) {
        this.gid = gid;
    }

    public byte[] getJpicture() {
        return jpicture;
    }

    public void setJpicture(byte[] jpicture) {
        this.jpicture = jpicture;
    }
}