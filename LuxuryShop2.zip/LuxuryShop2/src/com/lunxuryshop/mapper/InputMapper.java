package com.lunxuryshop.mapper;

import com.lunxuryshop.pojo.Input;
import com.lunxuryshop.pojo.InputExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface InputMapper {
	
	List<Input> selectByTypeid();

    List<Input> selectByGoodId(String gname);
    
    int countByExample(InputExample example);

    int deleteByExample(InputExample example);

    int deleteByPrimaryKey(Integer inid);

    int insert(Input record);

    int insertSelective(Input record);

    List<Input> selectByExample(InputExample example);

    Input selectByPrimaryKey(Integer inid);

    int updateByExampleSelective(@Param("record") Input record, @Param("example") InputExample example);

    int updateByExample(@Param("record") Input record, @Param("example") InputExample example);

    int updateByPrimaryKeySelective(Input record);

    int updateByPrimaryKey(Input record);
}