package com.lunxuryshop.mapper;

import com.lunxuryshop.pojo.Store;
import com.lunxuryshop.pojo.StoreExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface StoreMapper {
	
	List<Store> selectByTypeid(int typeid);
	
	Store selectByInid(int inid);
	//修改库存数据：名称或安全库存
	//Boolean updateByPrimaryId(int inid,int minnum);
	//模糊查询
	List<Store> vagueSelectShoes(String keywd);
	
    int countByExample(StoreExample example);

    int deleteByExample(StoreExample example);

    int deleteByPrimaryKey(Integer inid);
 
    int insert(Store record);

    int insertSelective(Store record);

    List<Store> selectByExample(StoreExample example);

    Store selectByPrimaryKey(Integer inid);

    int updateByExampleSelective(@Param("record") Store record, @Param("example") StoreExample example);

    int updateByExample(@Param("record") Store record, @Param("example") StoreExample example);

    int updateByPrimaryKeySelective(Store record);

    int updateByPrimaryKey(Store record);
}