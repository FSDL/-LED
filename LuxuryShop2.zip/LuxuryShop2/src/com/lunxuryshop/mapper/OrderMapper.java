package com.lunxuryshop.mapper;

import com.lunxuryshop.pojo.Order;
import com.lunxuryshop.pojo.OrderExample;
import com.lunxuryshop.pojo.OrderKey;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface OrderMapper {
    int countByExample(OrderExample example);

    int deleteByExample(OrderExample example);

    int deleteByPrimaryKey(OrderKey key);

    int insert(Order record);

    int insertSelective(Order record);

    List<Order> selectByExample(OrderExample example);

    Order selectByPrimaryKey(OrderKey key);

    int updateByExampleSelective(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByExample(@Param("record") Order record, @Param("example") OrderExample example);

    int updateByPrimaryKeySelective(Order record);

    int updateByPrimaryKey(Order record);
   
    int inserOrder(Order record);
    
    int countOrderid();
    
    List<Order> selectUserOrders(int userid);
    
    
    
}