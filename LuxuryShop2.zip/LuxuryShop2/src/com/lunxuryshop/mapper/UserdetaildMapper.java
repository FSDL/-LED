package com.lunxuryshop.mapper;

import com.lunxuryshop.pojo.Userdetaild;
import com.lunxuryshop.pojo.UserdetaildExample;

import java.util.HashMap;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserdetaildMapper {
    int countByExample(UserdetaildExample example);

    int deleteByExample(UserdetaildExample example);

    int deleteByPrimaryKey(Integer uid);

    int insert(Userdetaild record);

    int insertSelective(Userdetaild record);

    List<Userdetaild> selectByExample(UserdetaildExample example);

    Userdetaild selectByPrimaryKey(Integer uid);

    int updateByExampleSelective(@Param("record") Userdetaild record, @Param("example") UserdetaildExample example);

    int updateByExample(@Param("record") Userdetaild record, @Param("example") UserdetaildExample example);

    int updateByPrimaryKeySelective(Userdetaild record);

    int updateByPrimaryKey(Userdetaild record);
    
    //根据用户真实姓名查找用户信息
    List<Userdetaild> SelectByName(String name);
    
    List<Userdetaild> selectAll();
    
    //查询记录总数
    int selectCount();
    
    //分页查询
    List<Userdetaild> findByPage(HashMap<String,Object> map);
}